import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class contactTest {
    @Test
    void testGetters() {
        Contact contact = new Contact("135ABC", "Savion", "Peebles", "1231834211", "8939 Fairway Dr");

        assertEquals("135ABC", contact.getcontactID());
        assertEquals("Savion", contact.getfirstName());
        assertEquals("Peebles", contact.getlastName());
        assertEquals("1231834211", contact.getPhoneNumb());
        assertEquals("8939 Fairway Dr", contact.getAddress());
    }

    @Test
    void testSetters() {
    	Contact contact = new Contact("123DEF", "Marie", "Sanders", "1231834211", "8939 Hollow Dr");

        // call setters
    	contact.setcontactID("123DEF");
    	contact.setfirstName("Marie");
    	contact.setlastName("Sanders");
    	contact.setphoneNumb("1231834211");
    	contact.setaddress("8939 Hollow Dr");


        // assert that setters worked
        assertEquals("123DEF", contact.getcontactID());
        assertEquals("Marie", contact.getfirstName());
        assertEquals("Sanders", contact.getlastName());
        assertEquals("1231834211", contact.getPhoneNumb());
        assertEquals("8939 Hollow Dr", contact.getAddress());
    }
    @Test 
    void negativeTestforNull() 
    {
    Contact contact = new Contact("135ABC","Savion", "Peebles", "1231834211", "8939 Fairway Dr");
  
    // getters 
    assertThrows(IllegalArgumentException.class, () -> contact.setContactID(null));
    assertThrows(IllegalArgumentException.class, () -> contact.setFirstname(null));
    assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));
    assertThrows(IllegalArgumentException.class, () -> contact.setPhoneNum(null));
    assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));

    }
    @Test 
    void negativeTestforInvalidCharacters ()
    {
    	Contact contact = new Contact("136GHI","Josh", "Johnson", "1231834211", "8939 Ocean Dr");
    	  
 
        // getters 
        assertThrows(IllegalArgumentException.class, () -> contact.setContactID("123ABC567890000"));
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstname("joshitdfgsjdhcjd"));
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("Johnsonrerereghg"));
        assertThrows(IllegalArgumentException.class, () -> contact.setPhoneNum("12345678910"));
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress("8939 Ocean Dr, IN Marksville 47921"));