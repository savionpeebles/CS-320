import java.util.ArrayList;
import java.util.List;

public class ContactService 
{
	public List<Contact> contactList = new ArrayList<Contact>();

	public void newContact(String contactID, String firstName, String lastName, String phoneNumb, String address)  throws Exception 
	{
      for(int i = 0; i< contactList.size(); i++) {
        if (contactID.equals(contactList.get(i).getcontactID())) 
        {
        	 throw new IllegalArgumentException(" The contact already exists");       
        }
      }
      
      contactList.add(new Contact(contactID, firstName, lastName, phoneNumb, address));
	}

	public void deleteContact(String id)
    {
      for(int i = 0; i< contactList.size(); i++) {
        if (id.equals(contactList.get(i).getcontactID())) 
        {
        	contactList.remove(i);
        	return;
        }
        throw new IllegalArgumentException(" The contact is already deleted or does not exist");
      }
	}

	  public List<Contact> getContactList() 
	  { 
		  return contactList; 
	  }

}
