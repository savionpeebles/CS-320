// Savion Peebles
// Professor Lewis
// CS-320
// Contact Service

public class Contact 
{
	private String contactID;
	private String firstName;
	private String lastName;
	private String phoneNumb;
	private String address;
	
	private static final int CONTACTIDLENG = 10;
	private static final byte FIRSTNAMELENG = 10;
	private static final byte LASTNAMELENG = 10;
	private static final byte PHONENUMBLENG = 10;
	private static final byte ADDRESSLENG = 30;

	public void setcontactID(String contactID) 
	{
		if (contactID == null)
		{
			throw new IllegalArgumentException("The contact ID cannot be null");
		}
		else if (contactID.length()> CONTACTIDLENG)
		{
			throw new IllegalArgumentException("The contact ID cannot be longer than " + CONTACTIDLENG + " characters. The current length of the input is " + contactID.length());
		}
		else
		{
			this.contactID = contactID;
		}
			
	}
	public void setfirstName(String firstName)
	{
		if (firstName == null)
		{
				throw new IllegalArgumentException("The first name field cannot be null");
		}
		else if (firstName.length()> FIRSTNAMELENG)
		{
			throw new IllegalArgumentException("First name field must be longer than" + FIRSTNAMELENG + " characters. The current length of your input is:" + firstName.length());
		}
		else
		{
			this.firstName = firstName;
		}
		
	}
	public void setlastName(String lastName)
	{
		if (lastName == null)
		{
				throw new IllegalArgumentException("The last name field cannot be null");
		}
		else if (firstName.length()> LASTNAMELENG)
		{
			throw new IllegalArgumentException("Last name field must be longer than" + LASTNAMELENG + " characters. The current length of your input is:" + lastName.length());
		}
		else
		{
			this.lastName = lastName;
		}
		
	}
	public void setphoneNumb(String phoneNumb)
	{
		if (phoneNumb == null)
		{
				throw new IllegalArgumentException("The phone number field cannot be null");
		}
		else if (phoneNumb.length()> PHONENUMBLENG)
		{
			throw new IllegalArgumentException("First name field must be longer than" + PHONENUMBLENG + " characters. The current length of your input is:" + phoneNumb.length());
		}
		else
		{
			this.phoneNumb = phoneNumb;
		}
		
	}
	public void setaddress(String address )
	{
		if (address == null)
		{
				throw new IllegalArgumentException("The address field cannot be null");
		}
		else if (address.length()> ADDRESSLENG)
		{
			throw new IllegalArgumentException("Address field must be longer than" + ADDRESSLENG + " characters. The current length of your input is:" + address.length());
		}
		else
		{
			this.address = address;
		}
		
	}
	
	public String getcontactID()
	{
		return contactID;
	}
	public String getfirstName()
	{
		return firstName;
	}
	public String getlastName()
	{
		return lastName;
	}
	public String getPhoneNumb()
	{
		return phoneNumb;
	}
	public String getAddress()
	{
		return address;
	}
	
	public Contact (String contactID, String FN, String LN, String phone, String address)
	{
		setcontactID(contactID);
		setfirstName(FN);
		setlastName(LN);
		setphoneNumb(phone);
		setaddress(address);
	}
	
}

