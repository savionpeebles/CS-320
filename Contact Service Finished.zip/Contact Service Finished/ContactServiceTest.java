package(default.package);
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactServiceTest {

	   @Test // test new contact
	    void testNewContact() throws Exception
	    {
	        ContactService service = new ContactService();
	    	service.newContact("1234", "Savion", "Peeles","1231834211", "8932 Fairway Dr");
	        Contact contact = service.getContactList().get(0);
	        assertEquals("1234", contact.getcontactID());
	        assertEquals("Savion", contact.getfirstName());
	        assertEquals("Peeles", contact.getlastName());
	        assertEquals("1231834211", contact.getPhoneNumb());
	        assertEquals("8939 Fairway Dr", contact.getAddress());
	    }
	    @Test // delete last contact
	    void testdeleteTast() throws Exception
	    {
	    	ContactService service = new ContactService();
	        	service.newContact("1234", "Savion", "Peebles", "1231834211","8939 Fairway Dr");
				service.newContact("1334", "Marie", "Sanders", "1231834211","8939 Fairway Dr");
				service.newContact("1354", "Josh", "Johnson", "1231834211","8939 Fairway Dr");
			
	        assertEquals(3, service.getContactList().size());
	        service.deleteContact("1234");
	        assertEquals(2, service.getContactList().size());
	        service.deleteContact("1334");
	        assertEquals(1, service.getContactList().size());
	        service.deleteContact("1354");
	        assertEquals(0, service.getContactList().size());
	    }
	    @Test // new contact test
	    void negativeTestforNewContact () throws Exception
	    {
	    	ContactService service = new ContactService();
	       	service.newContact("1234", "Savion", "Peebles", "1231834321", "8939 Fairway Dr");
		  	assertThrows(IllegalArgumentException.class, () -> service.newContact("1234", "Savion", "Peebles", "1231834211", "8939 Fairway Dr"));
	    }
	    @Test //test for delete contact
	    void negativeTestforDeleteContact () throws Exception
	    {
	      ContactService service = new ContactService(); 
	       service.newContact("1234", "Savion", "Peeles", "1231834211", "8939 Fairway Dr");
	      assertThrows(IllegalArgumentException.class, () -> service.deleteContact("4567"));
	    }
}
